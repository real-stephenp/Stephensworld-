//This is the Mod for Cookie++

//This is the sequel from now on its too good to be a mod nobody heard of

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <windows.h>
using namespace std;

int main();

class gameData{
	public:
		int cookieCounter;
		int value;
		ofstream highscore;
		
		//Honestly I would have made a string array
		//and just display that but it would take
		//me an entire re skin of the backend code
		//on this.
		
		int displayLibrary(){	
		
		
			cout <<"c+Enter = +1 Cookies" << endl;
			cout <<"t+Enter = +1 TAGVAL"<< endl;
			cout <<"C5T5+Enter = +5 Cookies, -5 TAGVAL" << endl;
			cout <<"N+Enter = Make Highscore Negative"<< endl;
			cout <<"trd+Enter = Trades 1 Cookie for 1 TAGVAL"<< endl;
			cout <<"cmbn+Enter = Makes the scores equal to the sum of eachother"<< endl;
			
			cout <<"q+Enter = Quit and save" << endl;
			system("pause");
			main();
			
			//why the hell did i not bookmark this, making the 
			//commands is a tire so i'll have to make a bookmark
			//here...
		}
};
gameData gameDataObj;

int main();

int game();

int quitASave(){
	//I think the save feature was the most annoying.
	//In original dev and in the mod dev
	
	gameDataObj.highscore.open("highscore_modded.txt");
	gameDataObj.highscore << "High Score: " << gameDataObj.cookieCounter << endl;
	gameDataObj.highscore << "Tag Value/TAGVAL: " << gameDataObj.value << endl;
	gameDataObj.highscore.close();
	
	main();
}


int keystrokeRunner(string keys){
	
	int codeInput;
	
	if(keys=="c"){
		gameDataObj.cookieCounter=gameDataObj.cookieCounter+1;
	}
	else if(keys=="N"){
		gameDataObj.cookieCounter=gameDataObj.cookieCounter-gameDataObj.cookieCounter-gameDataObj.cookieCounter;
		gameDataObj.value=gameDataObj.value-gameDataObj.value-gameDataObj.value;
	}
	else if(keys=="trd"){
		gameDataObj.value++;
		gameDataObj.cookieCounter=gameDataObj.cookieCounter-1;
	}
	else if(keys=="cmdn"){
		gameDataObj.value=gameDataObj.cookieCounter+gameDataObj.value;
		gameDataObj.cookieCounter=gameDataObj.value;
	}
	else if(keys=="t"){
		gameDataObj.value=gameDataObj.value+1;
	}
	else if(keys=="q"){
		quitASave();
		
		//codeInput isnt needed here
		
		//that comment didnt age well did it
	}
	
	//OK now for a switch statement
	
	//now THAT comment is outdated
	
	//Im sick and tired of millions of "else if" statements
	//gonna have to modify it and make a more readable and
	//better optimized way to this function... why didn't i
	//use switch statements
	
	//yeah buddy last time i checked i don't think we have the privelege
	
	//OK now i realise i can't change this, i cant use a switch
	//statement on this one without the else if's... bummer
	
	//NOW THAT I ADDED THE TAG VALUE THIS BUG HAS BEEN
	//MAKING ME LOSE MY MIND MAN, WHENEVER I TYPE IN 
	// C TO THE GAME THE HIGHSCORE TOGGLES TO -10 AND 
	//THE TAG VALUE TURN TO -9 TF IS THIS
	
	//i still do not understand why this happened but apparently
	//the switch statement as a middle man is the reason...
	//guess i had a brain when making the original game
	game();
}

int game(){
	system("cls");
	cout <<"Cookies: "<< gameDataObj.cookieCounter << endl;
	cout <<"Tag Value: "<< gameDataObj.value << endl;
	cout <<"C+Enter = +1 Cookies" << endl;
	cout <<"T+Enter = +1 TAGVAL" << endl;
	string keystroke;
	
	cin >> keystroke;
	Beep(100,1000);
	
	keystrokeRunner(keystroke);
	
	//thank god we don't have a parameter
}

int openScore(){
	system("cls");
	ifstream openScorer;
	openScorer.open("highscore_modded.txt");
	char word[100];
	openScorer >> word;
	while(openScorer.good()){
		cout << word << " ";
		openScorer >> word;
	}
	system("pause");
	Beep(100,1000);
	main();
}

string devComms[50]={"//This is the Mod for Cookie++",
                     "    ",
                     "//This is the sequel from now on its too good to be a mod nobody heard of",
                     "    ",
                     "//Honestly I would have made a string array",
							"//and just display that but it would take",
							"//me an entire re skin of the backend code",
							"//on this",
							"    ",
							"//why the hell did i not bookmark this, making the",
							"//commands is a tire so i'll have to make a bookmark",
							"//here...",
							"    ",
							"//I think the save feature was the most annoying",
							"//In original dev and in the mod dev",
							"    ",
							"//codeInput isnt needed here",
							"    ",
							"//that comment didnt age well did it",
							"    ",
							"//OK now for a switch statement",
							"    ",
							"//now THAT comment is outdated",
							"    ",
							"//Im sick and tired of millions of else if statements",
							"//gonna have to modify it and make a more readable and",
							"//better optimized way to this function... why didn't i",
							"//use switch statements",
							"    ",
							"//yeah buddy last time i checked i don't think we have the privelege",
							"    ",
							"//OK now i realise i can't change this, i cant use a switch",
							"//statement on this one without the else if's... bummer",
							"    ",
							"//NOW THAT I ADDED THE TAG VALUE THIS BUG HAS BEEN",
							"//MAKING ME LOSE MY MIND MAN, WHENEVER I TYPE IN ",
							"// C TO THE GAME THE HIGHSCORE TOGGLES TO -10 AND ",
							"//THE TAG VALUE TURN TO -9 TF IS THIS",
							"    ",
							"//i still do not understand why this happened but apparently",
							"//the switch statement as a middle man is the reason...",
							"//guess i had a brain when making the original game",
							"    ",
							"//thank god we don't have a parameter",
							"    ",
							"//the mod is more optimized than game wtf i made this bruh",
							"    ",
							"//Instead of ctrl v'ing system cls in all statements",
							"//I could have just put one system cls before those..."};

int displayComms(){
	int x=0;
	
	while(x!=50){
		cout << devComms[x] << endl;
		x++;
	}
}

bool introPlayed=false;

int main(){
	if(introPlayed!=true){
		system("cls");
		cout <<"3"<< endl;
		
		Sleep(1000);
		system("cls");
		
		cout <<"3STR"<< endl;
		
		Sleep(1000);
		system("cls");
		
		cout <<"3STRIPE"<< endl;
		
		Beep(583,1500);
		
		Sleep(5000);
		
		introPlayed=true;
	}
	
	//the mod is more optimized than game wtf i made this bruh
	
	system("cls");
	cout <<"Cookie++ 2: On the Tag-Along"<< endl;
	cout <<"1> Play"<< endl;
	cout <<"2> Check Highscore"<< endl;
	cout <<"3> Controls/Keystroke Library"<< endl;
	cout <<"4> Extras"<< endl;
	cout <<"5> Settings"<< endl;
	
	string mainmenu;
	cin >> mainmenu;
	Beep(100,1000);
	
	system("cls");
	
	if(mainmenu=="1"){
		game();
	}
	else if(mainmenu=="2"){
		openScore();
	}
	else if(mainmenu=="3"){
		gameDataObj.displayLibrary();
	}
	else if(mainmenu=="4"){
		cout <<"1> Developer Comments"<< endl;
		cout <<"2> Credits"<< endl;
		cout <<"3> Back"<< endl;
		
		int extrasmenu;
		
		cin >> extrasmenu;
		Beep(100,1000);
		
		switch(extrasmenu){
			case 1:
				system("cls");
				displayComms();
				system("pause");
				main();
			case 2:
				system("cls");
				cout <<"   3STRIPE ENTERTAINMENT \n";
				cout <<"Lead Director: TK \n\n";
				cout <<"Concepts:"<< endl;
				cout <<"--Concept Commands: TK"<< endl;
				cout <<"--Delivered Concepts: TK"<< endl;
				cout <<"--Concept Features: TK"<< endl;
				cout <<"--Scrapped Concepts: My mother \n\n";
				cout <<"Programming: TK"<< endl;
				cout <<"There were no categories"<< endl;
				cout <<"Special Thanks to:"<< endl;
				cout <<"Adam and other friends at school"<< endl;
				cout <<"My mother"<< endl;
				cout <<"      THANKS FOR PLAYING!"<< endl;
				system("pause");
				Beep(100,1000);
				
				main();
			case 3:
				main();
		}
	}
	else if(mainmenu=="5"){
		system("cls");
		
		cout <<"1> Turn on Music"<< endl;
		cout <<"2> Back"<< endl;
		string settings;
		
		cin >> settings;
		
		if(settings=="1"){
			system("cls");
			
			cout <<"1> WeirdTown"<< endl;
			cout <<"2> Kill The Evil"<< endl;
			cout <<"3> Back"<< endl;
			string music;
			
			cin >> music;
			if(music=="1"){
				PlaySound("background-music-weirdtown.wav",NULL,SND_LOOP|SND_ASYNC);
				main();
			}
			else if(music=="2"){
				PlaySound("kill-the-evil.wav",NULL,SND_LOOP|SND_ASYNC);
				main();
			}
			else if(music=="3"){
				main();
			}
		}
		else if(settings=="2"){
			main();
		}
	}
	else{
		main();
	}
	
	//Instead of ctrl v'ing system cls in all statements
	//I could have just put one system cls before those...
}
